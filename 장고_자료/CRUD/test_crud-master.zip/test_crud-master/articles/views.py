from django.shortcuts import render,redirect
from .forms import ReviewForm
from .models import Review
from django.shortcuts import get_object_or_404
from django.views.decorators.http import require_POST
# Create your views here.

def index(request):
    reviews=Review.objects.all()
    context={
        'reviews':reviews
    }
    return render(request,'articles/index.html',context)

def create(request):
    if request.method=='POST':
        form=ReviewForm(request.POST)
        if form.is_valid():
            review=form.save()
            return redirect('articles:detail',review.id)
    else:
        form=ReviewForm()
    context={
        'form':form,
    }
    # return render(request,'articles/create.html',context)
    return render(request,'articles/form.html',context)


def detail(request,id):
    review=get_object_or_404(Review,id=id)
    context={
        'review':review,
    }
    return render(request,'articles/detail.html',context)


def update(request,id):
    review=get_object_or_404(Review,id=id)
    if request.method=='POST':
        form=ReviewForm(reqeust.POST,instance=review)
        if form.is_valid():
            review=form.save()
            return redirect('articles:detail',review.id)

    else:
        form=ReviewForm(instance=review)
    context={
        'form':form
    }

    return render(request,'articles/form.html',context)


@require_POST
def delete(request,id):
    review=get_object_or_404(Review,id=id)
    review.delete()
    return redirect('articles:index')
