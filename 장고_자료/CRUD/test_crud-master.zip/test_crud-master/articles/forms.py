from django import forms
from .models import Review
GENRE_SELECT=[
    ('action','액션'),
    ('mello','멜로'),
    ('comedy','코미디')
    ]

SUMMERY_SELECT=[
    ('one','재미한방'),
    ('two','눈물쏙'),
    ('three','통쾌 상쾌'),
    ('four','다시 보고 싶은 영화'),
    ]



class ReviewForm(forms.ModelForm):

    class Meta:
        model=Review
        fields='__all__'
        widgets={
            'genre':forms.RadioSelect(choices=GENRE_SELECT,
            attrs={
                'class':'text-primary'
            }
            ),
            'rank':forms.NumberInput(
                attrs={'min':'0','max':'10',
                    'class':'text-danger'
                }
                ),
            'summery':forms.CheckboxSelectMultiple(choices=SUMMERY_SELECT)

        }